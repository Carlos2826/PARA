import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel3-inundacion',
  templateUrl: './nivel3-inundacion.page.html',
  styleUrls: ['./nivel3-inundacion.page.scss'],
})
export class Nivel3InundacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
