import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Nivel3InundacionPage } from './nivel3-inundacion.page';

describe('Nivel3InundacionPage', () => {
  let component: Nivel3InundacionPage;
  let fixture: ComponentFixture<Nivel3InundacionPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Nivel3InundacionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
