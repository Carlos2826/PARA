import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seleccion-juego',
  templateUrl: './seleccion-juego.page.html',
  styleUrls: ['./seleccion-juego.page.scss'],
})
export class SeleccionJuegoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
