import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Nivel3DeslizamientoPage } from './nivel3-deslizamiento.page';

describe('Nivel3DeslizamientoPage', () => {
  let component: Nivel3DeslizamientoPage;
  let fixture: ComponentFixture<Nivel3DeslizamientoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Nivel3DeslizamientoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
