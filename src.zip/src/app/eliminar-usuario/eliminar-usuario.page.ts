import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eliminar-usuario',
  templateUrl: './eliminar-usuario.page.html',
  styleUrls: ['./eliminar-usuario.page.scss'],
})
export class EliminarUsuarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
