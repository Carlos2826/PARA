import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anadir-contenido',
  templateUrl: './anadir-contenido.page.html',
  styleUrls: ['./anadir-contenido.page.scss'],
})
export class AnadirContenidoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
