import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel2-inundacion',
  templateUrl: './nivel2-inundacion.page.html',
  styleUrls: ['./nivel2-inundacion.page.scss'],
})
export class Nivel2InundacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
