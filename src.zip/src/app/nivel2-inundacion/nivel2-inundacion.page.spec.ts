import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Nivel2InundacionPage } from './nivel2-inundacion.page';

describe('Nivel2InundacionPage', () => {
  let component: Nivel2InundacionPage;
  let fixture: ComponentFixture<Nivel2InundacionPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Nivel2InundacionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
