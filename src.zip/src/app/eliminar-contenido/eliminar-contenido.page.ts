import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eliminar-contenido',
  templateUrl: './eliminar-contenido.page.html',
  styleUrls: ['./eliminar-contenido.page.scss'],
})
export class EliminarContenidoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
