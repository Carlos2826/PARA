import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Nivel2DeslizamientoPage } from './nivel2-deslizamiento.page';

describe('Nivel2DeslizamientoPage', () => {
  let component: Nivel2DeslizamientoPage;
  let fixture: ComponentFixture<Nivel2DeslizamientoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Nivel2DeslizamientoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
