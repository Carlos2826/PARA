import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel1-inundacion',
  templateUrl: './nivel1-inundacion.page.html',
  styleUrls: ['./nivel1-inundacion.page.scss'],
})
export class Nivel1InundacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
