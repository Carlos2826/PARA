import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-juego-deslizamiento',
  templateUrl: './juego-deslizamiento.page.html',
  styleUrls: ['./juego-deslizamiento.page.scss'],
})
export class JuegoDeslizamientoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
