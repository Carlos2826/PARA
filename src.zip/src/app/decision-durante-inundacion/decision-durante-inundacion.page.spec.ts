import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DecisionDuranteInundacionPage } from './decision-durante-inundacion.page';

describe('DecisionDuranteInundacionPage', () => {
  let component: DecisionDuranteInundacionPage;
  let fixture: ComponentFixture<DecisionDuranteInundacionPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DecisionDuranteInundacionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
