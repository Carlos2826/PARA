import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel2-deslizamiento',
  templateUrl: './nivel2-deslizamiento.page.html',
  styleUrls: ['./nivel2-deslizamiento.page.scss'],
})
export class Nivel2DeslizamientoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
