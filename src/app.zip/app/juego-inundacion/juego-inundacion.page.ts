import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-juego-inundacion',
  templateUrl: './juego-inundacion.page.html',
  styleUrls: ['./juego-inundacion.page.scss'],
})
export class JuegoInundacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
