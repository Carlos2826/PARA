import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel3-deslizamiento',
  templateUrl: './nivel3-deslizamiento.page.html',
  styleUrls: ['./nivel3-deslizamiento.page.scss'],
})
export class Nivel3DeslizamientoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
