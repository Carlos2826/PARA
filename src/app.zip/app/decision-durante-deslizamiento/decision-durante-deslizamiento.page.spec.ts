import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DecisionDuranteDeslizamientoPage } from './decision-durante-deslizamiento.page';

describe('DecisionDuranteDeslizamientoPage', () => {
  let component: DecisionDuranteDeslizamientoPage;
  let fixture: ComponentFixture<DecisionDuranteDeslizamientoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DecisionDuranteDeslizamientoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
