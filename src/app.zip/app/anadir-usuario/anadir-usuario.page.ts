import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anadir-usuario',
  templateUrl: './anadir-usuario.page.html',
  styleUrls: ['./anadir-usuario.page.scss'],
})
export class AnadirUsuarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
