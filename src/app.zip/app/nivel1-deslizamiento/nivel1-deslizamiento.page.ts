import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nivel1-deslizamiento',
  templateUrl: './nivel1-deslizamiento.page.html',
  styleUrls: ['./nivel1-deslizamiento.page.scss'],
})
export class Nivel1DeslizamientoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
